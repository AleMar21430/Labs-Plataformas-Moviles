package com.marti21430.lab11.datasource.util

const val API_URL = "https://rickandmortyapi.com"