package com.marti21430.lab11.datasource.model

data class CharactersResponse(
    val results: MutableList<Character>
)
