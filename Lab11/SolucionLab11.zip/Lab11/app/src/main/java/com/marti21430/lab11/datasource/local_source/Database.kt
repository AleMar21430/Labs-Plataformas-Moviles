package com.marti21430.lab11.datasource.local_source

class Database {
}