package com.marti21430.lab11.datasource.local_source

interface User {
}