package com.marti21430.lab11.datasource.model

data class Origin(
    val name: String,
    val url: String
)
